﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CaRental.Migrations
{
    public partial class n : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CategoryModels",
                columns: table => new
                {
                    IdCategory = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CategoryName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CategoryModels", x => x.IdCategory);
                });

            migrationBuilder.CreateTable(
                name: "Person",
                columns: table => new
                {
                    IdPerson = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    Nickname = table.Column<string>(nullable: true),
                    Driving_habits = table.Column<string>(nullable: true),
                    Driver_experience = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Person", x => x.IdPerson);
                });

            migrationBuilder.CreateTable(
                name: "Rental",
                columns: table => new
                {
                    IdRental = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Start = table.Column<DateTime>(nullable: false),
                    End = table.Column<DateTime>(nullable: false),
                    Priceperday = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rental", x => x.IdRental);
                });

            migrationBuilder.CreateTable(
                name: "Car",
                columns: table => new
                {
                    IdCar = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Brand = table.Column<string>(nullable: true),
                    Model = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    Km = table.Column<int>(nullable: false),
                    CategoryModelsIdCategory = table.Column<int>(nullable: true),
                    CategoryId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Car", x => x.IdCar);
                    table.ForeignKey(
                        name: "FK_Car_CategoryModels_CategoryModelsIdCategory",
                        column: x => x.CategoryModelsIdCategory,
                        principalTable: "CategoryModels",
                        principalColumn: "IdCategory",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Car",
                columns: new[] { "IdCar", "Brand", "CategoryId", "CategoryModelsIdCategory", "Description", "Km", "Model" },
                values: new object[,]
                {
                    { 1, "Audi", 1, null, "hehehehehe", 20, "Audi Q7" },
                    { 2, "Audi", 1, null, "huhuhu", 20, "Audi Q4" },
                    { 3, "Audi A3", 2, null, "hahahaha", 30, "Audi Q7" },
                    { 4, "Audi A4", 1, null, "hihihi", 30, "Audi Q7" }
                });

            migrationBuilder.InsertData(
                table: "CategoryModels",
                columns: new[] { "IdCategory", "CategoryName" },
                values: new object[,]
                {
                    { 1, "Sedan" },
                    { 2, "Hatchback" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Car_CategoryModelsIdCategory",
                table: "Car",
                column: "CategoryModelsIdCategory");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Car");

            migrationBuilder.DropTable(
                name: "Person");

            migrationBuilder.DropTable(
                name: "Rental");

            migrationBuilder.DropTable(
                name: "CategoryModels");
        }
    }
}
