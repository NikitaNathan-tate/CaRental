﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CaRental.Migrations
{
    public partial class allmu : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Car_CategoryModels_CategoryModelsIdCategory",
                table: "Car");

            migrationBuilder.DropIndex(
                name: "IX_Car_CategoryModelsIdCategory",
                table: "Car");

            migrationBuilder.DropColumn(
                name: "CategoryId",
                table: "Car");

            migrationBuilder.DropColumn(
                name: "CategoryModelsIdCategory",
                table: "Car");

            migrationBuilder.AddColumn<int>(
                name: "CategoryIdCategory",
                table: "Car",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "IdCategory",
                table: "Car",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.UpdateData(
                table: "Car",
                keyColumn: "IdCar",
                keyValue: 1,
                column: "IdCategory",
                value: 1);

            migrationBuilder.UpdateData(
                table: "Car",
                keyColumn: "IdCar",
                keyValue: 2,
                column: "IdCategory",
                value: 1);

            migrationBuilder.UpdateData(
                table: "Car",
                keyColumn: "IdCar",
                keyValue: 3,
                column: "IdCategory",
                value: 2);

            migrationBuilder.UpdateData(
                table: "Car",
                keyColumn: "IdCar",
                keyValue: 4,
                column: "IdCategory",
                value: 1);

            migrationBuilder.CreateIndex(
                name: "IX_Car_CategoryIdCategory",
                table: "Car",
                column: "CategoryIdCategory");

            migrationBuilder.AddForeignKey(
                name: "FK_Car_CategoryModels_CategoryIdCategory",
                table: "Car",
                column: "CategoryIdCategory",
                principalTable: "CategoryModels",
                principalColumn: "IdCategory",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Car_CategoryModels_CategoryIdCategory",
                table: "Car");

            migrationBuilder.DropIndex(
                name: "IX_Car_CategoryIdCategory",
                table: "Car");

            migrationBuilder.DropColumn(
                name: "CategoryIdCategory",
                table: "Car");

            migrationBuilder.DropColumn(
                name: "IdCategory",
                table: "Car");

            migrationBuilder.AddColumn<int>(
                name: "CategoryId",
                table: "Car",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CategoryModelsIdCategory",
                table: "Car",
                type: "int",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Car",
                keyColumn: "IdCar",
                keyValue: 1,
                column: "CategoryId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "Car",
                keyColumn: "IdCar",
                keyValue: 2,
                column: "CategoryId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "Car",
                keyColumn: "IdCar",
                keyValue: 3,
                column: "CategoryId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "Car",
                keyColumn: "IdCar",
                keyValue: 4,
                column: "CategoryId",
                value: 1);

            migrationBuilder.CreateIndex(
                name: "IX_Car_CategoryModelsIdCategory",
                table: "Car",
                column: "CategoryModelsIdCategory");

            migrationBuilder.AddForeignKey(
                name: "FK_Car_CategoryModels_CategoryModelsIdCategory",
                table: "Car",
                column: "CategoryModelsIdCategory",
                principalTable: "CategoryModels",
                principalColumn: "IdCategory",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
