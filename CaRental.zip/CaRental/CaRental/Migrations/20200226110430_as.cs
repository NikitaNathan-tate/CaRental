﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CaRental.Migrations
{
    public partial class @as : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Car_CategoryModels_CategoryIdCategory",
                table: "Car");

            migrationBuilder.DropIndex(
                name: "IX_Car_CategoryIdCategory",
                table: "Car");

            migrationBuilder.DropColumn(
                name: "CategoryIdCategory",
                table: "Car");

            migrationBuilder.AddColumn<int>(
                name: "CarModelsIdCar",
                table: "Rental",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "IdCar",
                table: "Rental",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CategoryModelsIdCategory",
                table: "Car",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Rental_CarModelsIdCar",
                table: "Rental",
                column: "CarModelsIdCar");

            migrationBuilder.CreateIndex(
                name: "IX_Car_CategoryModelsIdCategory",
                table: "Car",
                column: "CategoryModelsIdCategory");

            migrationBuilder.AddForeignKey(
                name: "FK_Car_CategoryModels_CategoryModelsIdCategory",
                table: "Car",
                column: "CategoryModelsIdCategory",
                principalTable: "CategoryModels",
                principalColumn: "IdCategory",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Rental_Car_CarModelsIdCar",
                table: "Rental",
                column: "CarModelsIdCar",
                principalTable: "Car",
                principalColumn: "IdCar",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Car_CategoryModels_CategoryModelsIdCategory",
                table: "Car");

            migrationBuilder.DropForeignKey(
                name: "FK_Rental_Car_CarModelsIdCar",
                table: "Rental");

            migrationBuilder.DropIndex(
                name: "IX_Rental_CarModelsIdCar",
                table: "Rental");

            migrationBuilder.DropIndex(
                name: "IX_Car_CategoryModelsIdCategory",
                table: "Car");

            migrationBuilder.DropColumn(
                name: "CarModelsIdCar",
                table: "Rental");

            migrationBuilder.DropColumn(
                name: "IdCar",
                table: "Rental");

            migrationBuilder.DropColumn(
                name: "CategoryModelsIdCategory",
                table: "Car");

            migrationBuilder.AddColumn<int>(
                name: "CategoryIdCategory",
                table: "Car",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Car_CategoryIdCategory",
                table: "Car",
                column: "CategoryIdCategory");

            migrationBuilder.AddForeignKey(
                name: "FK_Car_CategoryModels_CategoryIdCategory",
                table: "Car",
                column: "CategoryIdCategory",
                principalTable: "CategoryModels",
                principalColumn: "IdCategory",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
