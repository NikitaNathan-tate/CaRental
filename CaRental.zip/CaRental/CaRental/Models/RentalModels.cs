﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CaRental.Models
{
    public class RentalModels
    {
        [Key]
        public int IdRental { get; set; }

        public DateTime Start { get; set; }

        public DateTime End { get; set; }

        public string Priceperday { get; set; }




    }
}
